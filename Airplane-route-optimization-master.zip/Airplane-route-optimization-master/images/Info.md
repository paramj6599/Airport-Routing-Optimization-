Required Images for both read me.md and for the project.
